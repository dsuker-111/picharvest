﻿import { chromium } from 'playwright';
import { readFileSync } from 'node:fs';
const base='C:/Users/lx/Documents/deepseek-harness/default-workspace/gh-tmp';
const data=JSON.parse(readFileSync(base+'/cookies.json','utf8'));
const cookies=data.cookies.filter(c=>c.name&&c.value&&/(^|\.)github\.com$/.test(c.domain)).map(c=>({name:c.name,value:c.value,domain:c.domain,path:c.path||'/',expires:typeof c.expirationDate==='number'?Math.round(c.expirationDate):-1,httpOnly:!!c.httpOnly,secure:!!c.secure,sameSite:['Strict','Lax','None'].includes(c.sameSite)?c.sameSite:'Lax'}));
const browser=await chromium.launch({headless:true}); const ctx=await browser.newContext({ignoreHTTPSErrors:true,userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0'}); await ctx.addCookies(cookies);
for(const url of ['https://github.com/repositories','https://github.com/repositories/new','https://github.com/repos']){
 try { const r=await ctx.request.post(url,{form:{owner:'dsuker-111','repository[name]':'picharvest','repository[description]':'图仓 PicHarvest — 电商图片下载器','repository[visibility]':'public','repository[auto_init]':'true'},headers:{Accept:'application/json','X-Requested-With':'XMLHttpRequest'},maxRedirects:0,timeout:30000}); console.log(url,r.status(),r.headers()['location'],(await r.text()).slice(0,300)); } catch(e){console.log(url,'ERR',e.message)}
}
await browser.close();
