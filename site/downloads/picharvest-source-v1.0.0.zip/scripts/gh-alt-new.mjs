﻿import { chromium } from 'playwright';
import { readFileSync } from 'node:fs';
const base='C:/Users/lx/Documents/deepseek-harness/default-workspace/gh-tmp';
const data=JSON.parse(readFileSync(base+'/cookies.json','utf8'));
const cookies=data.cookies.filter(c=>c.name&&c.value&&/(^|\.)github\.com$/.test(c.domain)).map(c=>({name:c.name,value:c.value,domain:c.domain,path:c.path||'/',expires:typeof c.expirationDate==='number'?Math.round(c.expirationDate):-1,httpOnly:!!c.httpOnly,secure:!!c.secure,sameSite:['Strict','Lax','None'].includes(c.sameSite)?c.sameSite:'Lax'}));
const b=await chromium.launch({headless:true}); const ctx=await b.newContext({ignoreHTTPSErrors:true,userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0'}); await ctx.addCookies(cookies);
for(const u of ['https://github.com/repositories/new','https://github.com/new?repo_name=picharvest','https://github.com/new?template_name=']){ const r=await ctx.request.get(u,{headers:{Accept:'text/html'}}); const h=await r.text(); console.log(u,r.status(),h.length,'form',h.includes('<form'),'token',/authenticity_token/.test(h)); }
await b.close();
