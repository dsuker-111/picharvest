﻿import { chromium } from 'playwright';
import { readFileSync, writeFileSync } from 'node:fs';
const base='C:/Users/lx/Documents/deepseek-harness/default-workspace/gh-tmp';
const device=JSON.parse(readFileSync(base+'/device.json','utf8').replace(/^\uFEFF/,''));
const data=JSON.parse(readFileSync(base+'/cookies.json','utf8'));
const cookies=data.cookies.filter(c=>c.name&&c.value&&/(^|\.)github\.com$/.test(c.domain)).map(c=>({name:c.name,value:c.value,domain:c.domain,path:c.path||'/',expires:typeof c.expirationDate==='number'?Math.round(c.expirationDate):-1,httpOnly:!!c.httpOnly,secure:!!c.secure,sameSite:['Strict','Lax','None'].includes(c.sameSite)?c.sameSite:'Lax'}));
const browser=await chromium.launch({headless:true});
const ctx=await browser.newContext({ignoreHTTPSErrors:true,userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0'});
await ctx.addCookies(cookies);
const page=await ctx.newPage(); await page.goto('https://github.com/login/device/select_account',{waitUntil:'commit',timeout:60000}); await page.waitForTimeout(500);
let html=await (await ctx.request.get('https://github.com/login/device/select_account')).text();
let token=html.match(/name="authenticity_token" value="([^"]+)"/)?.[1];
let r=await ctx.request.post('https://github.com/login/device/select_account',{form:{authenticity_token:token},maxRedirects:0,headers:{Referer:'https://github.com/login/device/select_account'}});
console.log('select',r.status(),r.headers()['location']);
html=await (await ctx.request.get('https://github.com/login/device?skip_account_picker=true')).text();
token=html.match(/name="authenticity_token" value="([^"]+)"/)?.[1];
const code=device.user_code.replace('-','');
const form={authenticity_token:token,commit:'Continue'};
for(let i=0;i<code.length;i++){ const idx=i<4?i:i+1; form[`user-code-${idx}`]=code[i]; }
r=await ctx.request.post('https://github.com/login/device/confirmation',{form,maxRedirects:0,headers:{Referer:'https://github.com/login/device?skip_account_picker=true'}});
console.log('code post',r.status(),r.headers()['location']);
const loc=r.headers()['location'];
if(loc){ html=await (await ctx.request.get(new URL(loc,'https://github.com').href)).text(); }
else { html=await r.text(); }
writeFileSync(base+'/authorize.html',html);
console.log('auth len',html.length,'authorize',/Authorize/i.test(html),'token',/name="authenticity_token" value="([^"]+)"/.test(html));
for (const m of html.matchAll(/<form[^>]*>[\s\S]{0,1200}?<\/form>/gi)) console.log('FORM',m[0].slice(0,1000));
await browser.close();
