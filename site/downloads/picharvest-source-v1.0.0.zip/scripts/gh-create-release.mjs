﻿import { chromium } from 'playwright';
import { readFileSync } from 'node:fs';
const base='C:/Users/lx/Documents/deepseek-harness/default-workspace/gh-tmp';
const data=JSON.parse(readFileSync(base+'/cookies.json','utf8'));
const cookies=data.cookies.filter(c=>c.name&&c.value&&/(^|\.)github\.com$/.test(c.domain)).map(c=>({name:c.name,value:c.value,domain:c.domain,path:c.path||'/',expires:typeof c.expirationDate==='number'?Math.round(c.expirationDate):-1,httpOnly:!!c.httpOnly,secure:!!c.secure,sameSite:['Strict','Lax','None'].includes(c.sameSite)?c.sameSite:'Lax'}));
const b=await chromium.launch({headless:false,channel:'chromium',args:['--disable-blink-features=AutomationControlled']}); const ctx=await b.newContext({ignoreHTTPSErrors:true,viewport:{width:1280,height:1000},userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0'}); await ctx.addCookies(cookies);
const page=await ctx.newPage(); await page.goto('https://github.com/dsuker-111/picharvest/releases/new',{waitUntil:'domcontentloaded',timeout:60000}); await page.waitForTimeout(3500);
await page.evaluate(()=>{const t=document.querySelector('#release_tag_name'); if(t){t.value='v1.0.0'; t.dispatchEvent(new Event('input',{bubbles:true})); t.dispatchEvent(new Event('change',{bubbles:true}));}});
await page.locator('#release_name').fill('图仓 PicHarvest v1.0.0');
await page.locator('#release_body').fill('## 图仓 PicHarvest v1.0.0\n\n电商图片下载器 Chrome / Edge 扩展。\n\n- 商品页图片扫描、自动去重、原图优先\n- ZIP 打包 / 逐张下载\n- 本地处理，无账号、无后端\n\n官网：https://picharvest-2026.surge.sh\n\n安装包：下载下方 `picharvest-extension-v1.0.0.zip`。');
await page.locator('#releases-upload').setInputFiles('C:/Users/lx/Documents/deepseek-harness/default-workspace/picharvest/site/downloads/picharvest-extension-v1.0.0.zip');
for(let i=0;i<40;i++){await page.waitForTimeout(1000); const t=await page.locator('body').innerText(); if(!/Uploading|上传/.test(t)) break;}
console.log((await page.locator('body').innerText()).slice(0,900));
const publish=page.getByRole('button',{name:'Publish release'}); console.log('publish',await publish.count(),await publish.isDisabled()); await publish.click();
await page.waitForTimeout(8000); console.log('URL',page.url()); console.log((await page.locator('body').innerText()).slice(0,900)); await page.screenshot({path:base+'/release-created.png'}); await b.close();
