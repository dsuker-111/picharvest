﻿import { chromium } from 'playwright';
import { readFileSync } from 'node:fs';
const base='C:/Users/lx/Documents/deepseek-harness/default-workspace/gh-tmp';
const data=JSON.parse(readFileSync(base+'/cookies.json','utf8'));
const cookies=data.cookies.filter(c=>c.name&&c.value&&/(^|\.)github\.com$/.test(c.domain)).map(c=>({name:c.name,value:c.value,domain:c.domain,path:c.path||'/',expires:typeof c.expirationDate==='number'?Math.round(c.expirationDate):-1,httpOnly:!!c.httpOnly,secure:!!c.secure,sameSite:['Strict','Lax','None'].includes(c.sameSite)?c.sameSite:'Lax'}));
const b=await chromium.launch({headless:true}); const ctx=await b.newContext({ignoreHTTPSErrors:true,userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0'}); await ctx.addCookies(cookies);
const page=await ctx.newPage(); await page.goto('https://github.com/new',{waitUntil:'commit',timeout:60000}); await page.waitForTimeout(1000);
for(const [url,body] of [
 ['https://github.com/repositories',{owner:'dsuker-111',name:'picharvest',description:'图仓 PicHarvest',visibility:'public',auto_init:true}],
 ['https://github.com/repositories',{repository:{name:'picharvest',description:'图仓 PicHarvest',visibility:'public',auto_init:true}}]
]){ try{const r=await page.evaluate(async({url,body})=>{const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify(body)});return {status:r.status,text:(await r.text()).slice(0,300)}},{url,body}); console.log(url,r);}catch(e){console.log('ERR',e.message)} }
await b.close();
