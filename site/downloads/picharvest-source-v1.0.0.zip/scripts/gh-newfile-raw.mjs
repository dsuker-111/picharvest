﻿import { chromium } from 'playwright';
import { readFileSync, writeFileSync } from 'node:fs';
const base='C:/Users/lx/Documents/deepseek-harness/default-workspace/gh-tmp';
const data=JSON.parse(readFileSync(base+'/cookies.json','utf8'));
const cookies=data.cookies.filter(c=>c.name&&c.value&&/(^|\.)github\.com$/.test(c.domain)).map(c=>({name:c.name,value:c.value,domain:c.domain,path:c.path||'/',expires:typeof c.expirationDate==='number'?Math.round(c.expirationDate):-1,httpOnly:!!c.httpOnly,secure:!!c.secure,sameSite:['Strict','Lax','None'].includes(c.sameSite)?c.sameSite:'Lax'}));
const b=await chromium.launch({headless:true}); const ctx=await b.newContext({ignoreHTTPSErrors:true,userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0'}); await ctx.addCookies(cookies);
const r=await ctx.request.get('https://github.com/dsuker-111/picharvest/new/main?filename=README.md',{headers:{Accept:'text/html'},timeout:30000}); const h=await r.text(); writeFileSync(base+'/newfile.html',h); console.log(r.status(),h.length,'token',/authenticity_token/.test(h),'form',h.includes('<form')); console.log(h.slice(0,300));
await b.close();
