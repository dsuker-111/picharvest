﻿import { chromium } from 'playwright';
import { readFileSync } from 'node:fs';
const base='C:/Users/lx/Documents/deepseek-harness/default-workspace/gh-tmp';
const data=JSON.parse(readFileSync(base+'/cookies.json','utf8'));
const cookies=data.cookies.filter(c=>c.name&&c.value&&/(^|\.)github\.com$/.test(c.domain)).map(c=>({name:c.name,value:c.value,domain:c.domain,path:c.path||'/',expires:typeof c.expirationDate==='number'?Math.round(c.expirationDate):-1,httpOnly:!!c.httpOnly,secure:!!c.secure,sameSite:['Strict','Lax','None'].includes(c.sameSite)?c.sameSite:'Lax'}));
const b=await chromium.launch({headless:true}); const ctx=await b.newContext({ignoreHTTPSErrors:true,userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0'}); await ctx.addCookies(cookies);
const page=await ctx.newPage(); await page.goto('https://github.com/new',{waitUntil:'commit',timeout:60000}); await page.waitForTimeout(2000);
const res=await page.evaluate(async()=>{
 const f=new FormData();
 f.append('owner','dsuker-111');
 f.append('repository[name]','picharvest');
 f.append('repository[description]','图仓 PicHarvest — 电商图片下载器');
 f.append('repository[visibility]','public');
 f.append('repository[auto_init]','true');
 const r=await fetch('/repositories',{method:'POST',body:f,headers:{Accept:'application/json'}});
 return {status:r.status,url:r.url,text:(await r.text()).slice(0,800)};
});
console.log(res);
await b.close();
