﻿import { chromium } from 'playwright';
import { readFileSync } from 'node:fs';
const base='C:/Users/lx/Documents/deepseek-harness/default-workspace/gh-tmp';
const data=JSON.parse(readFileSync(base+'/cookies.json','utf8'));
const cookies=data.cookies.filter(c=>c.name&&c.value&&/(^|\.)github\.com$/.test(c.domain)).map(c=>({name:c.name,value:c.value,domain:c.domain,path:c.path||'/',expires:typeof c.expirationDate==='number'?Math.round(c.expirationDate):-1,httpOnly:!!c.httpOnly,secure:!!c.secure,sameSite:['Strict','Lax','None'].includes(c.sameSite)?c.sameSite:'Lax'}));
const b=await chromium.launch({headless:false,channel:'chromium',args:['--disable-blink-features=AutomationControlled']}); const ctx=await b.newContext({ignoreHTTPSErrors:true,viewport:{width:1280,height:900},userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0'}); await ctx.addCookies(cookies);
const page=await ctx.newPage(); await page.goto('https://github.com/new',{waitUntil:'domcontentloaded',timeout:60000}).catch(e=>console.log('goto',e.message)); await page.waitForTimeout(5000);
console.log('title',await page.title(),'url',page.url()); console.log((await page.locator('body').innerText()).slice(0,1200)); console.log('inputs',await page.locator('input').count());
await page.screenshot({path:base+'/new-headful.png'}); await b.close();
