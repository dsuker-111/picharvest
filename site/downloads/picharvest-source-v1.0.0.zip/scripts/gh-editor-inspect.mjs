﻿import { chromium } from 'playwright';
import { readFileSync } from 'node:fs';
const base='C:/Users/lx/Documents/deepseek-harness/default-workspace/gh-tmp';
const data=JSON.parse(readFileSync(base+'/cookies.json','utf8'));
const cookies=data.cookies.filter(c=>c.name&&c.value&&/(^|\.)github\.com$/.test(c.domain)).map(c=>({name:c.name,value:c.value,domain:c.domain,path:c.path||'/',expires:typeof c.expirationDate==='number'?Math.round(c.expirationDate):-1,httpOnly:!!c.httpOnly,secure:!!c.secure,sameSite:['Strict','Lax','None'].includes(c.sameSite)?c.sameSite:'Lax'}));
const b=await chromium.launch({headless:false,channel:'chromium',args:['--disable-blink-features=AutomationControlled']}); const ctx=await b.newContext({ignoreHTTPSErrors:true,viewport:{width:1280,height:1000},userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0'}); await ctx.addCookies(cookies);
const page=await ctx.newPage(); await page.goto('https://github.com/dsuker-111/picharvest/new/main?filename=README.md',{waitUntil:'domcontentloaded',timeout:60000}); await page.waitForTimeout(7000);
const info=await page.evaluate(()=>{
 const out={};
 out.active={tag:document.activeElement?.tagName,id:document.activeElement?.id,cls:document.activeElement?.className,name:document.activeElement?.name};
 out.editables=[...document.querySelectorAll('[contenteditable],textarea,[role=textbox]')].map(e=>({tag:e.tagName,id:e.id,cls:e.className,ce:e.getAttribute('contenteditable'),role:e.getAttribute('role'),name:e.name,aria:e.getAttribute('aria-label')}));
 const ec=[...document.querySelectorAll('*')].find(e=>(e.textContent||'').trim()==='Enter file contents here');
 if(ec){let n=ec; let arr=[]; for(let i=0;i<5&&n;i++){arr.push({tag:n.tagName,cls:n.className,id:n.id,html:n.outerHTML.slice(0,300)});n=n.parentElement;} out.editor=arr;}
 return out;
});
console.log(JSON.stringify(info,null,2));
await b.close();
