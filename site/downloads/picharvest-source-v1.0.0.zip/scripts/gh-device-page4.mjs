﻿import { chromium } from 'playwright';
import { readFileSync } from 'node:fs';
const base='C:/Users/lx/Documents/deepseek-harness/default-workspace/gh-tmp';
const data=JSON.parse(readFileSync(base+'/cookies.json','utf8'));
const cookies=data.cookies.filter(c=>c.name&&c.value&&/(^|\.)github\.com$/.test(c.domain)).map(c=>({name:c.name,value:c.value,domain:c.domain,path:c.path||'/',expires:typeof c.expirationDate==='number'?Math.round(c.expirationDate):-1,httpOnly:!!c.httpOnly,secure:!!c.secure,sameSite:['Strict','Lax','None'].includes(c.sameSite)?c.sameSite:'Lax'}));
const browser=await chromium.launch({headless:true});
const ctx=await browser.newContext({viewport:{width:1100,height:900},ignoreHTTPSErrors:true,userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0'});
await ctx.addCookies(cookies);
const page=await ctx.newPage();
await page.goto('https://github.com/login/device/select_account',{waitUntil:'commit',timeout:60000});
await page.waitForTimeout(3000);
const html=await page.content();
console.log('url',page.url(),'len',html.length,'token',/name="authenticity_token" value="([^"]+)"/.test(html));
console.log((await page.locator('body').innerText()).slice(0,300));
const token=html.match(/name="authenticity_token" value="([^"]+)"/)?.[1];
if(token){
 const res=await page.evaluate(async(t)=>{const r=await fetch('/login/device/select_account',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({authenticity_token:t}),redirect:'follow'});return {status:r.status,url:r.url}},token);
 console.log('post',res);
}
await page.goto('https://github.com/login/device?skip_account_picker=true',{waitUntil:'commit',timeout:60000});
await page.waitForTimeout(2500);
console.log('url2',page.url());
console.log((await page.locator('body').innerText()).slice(0,600));
console.log('inputs',await page.locator('input').count());
await browser.close();
