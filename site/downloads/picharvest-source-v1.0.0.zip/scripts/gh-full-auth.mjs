import { chromium } from "playwright";
import { readFileSync, writeFileSync } from "node:fs";

const base = "C:/Users/lx/Documents/deepseek-harness/default-workspace/gh-tmp";
const data = JSON.parse(readFileSync(base + "/cookies.json", "utf8"));
const cookies = data.cookies
  .filter((c) => c.name && c.value && /(^|\.)github\.com$/.test(c.domain))
  .map((c) => ({
    name: c.name,
    value: c.value,
    domain: c.domain,
    path: c.path || "/",
    expires: typeof c.expirationDate === "number" ? Math.round(c.expirationDate) : -1,
    httpOnly: !!c.httpOnly,
    secure: !!c.secure,
    sameSite: ["Strict", "Lax", "None"].includes(c.sameSite) ? c.sameSite : "Lax"
  }));

const browser = await chromium.launch({ headless: true });
const ctx = await browser.newContext({
  ignoreHTTPSErrors: true,
  userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0"
});
await ctx.addCookies(cookies);
const page = await ctx.newPage();
await page.goto("https://github.com/login/device/select_account", { waitUntil: "commit", timeout: 60000 });
await page.waitForTimeout(500);

const deviceResp = await ctx.request.post("https://github.com/login/device/code", {
  form: { client_id: "Iv1.b507a08c87ecfe98", scope: "repo read:user" },
  headers: { Accept: "application/json" },
  timeout: 30000
});
const device = JSON.parse(await deviceResp.text());
console.log("device code", deviceResp.status(), device.user_code);

let html = await (await ctx.request.get("https://github.com/login/device/select_account")).text();
let token = html.match(/name="authenticity_token" value="([^"]+)"/)?.[1];
let resp = await ctx.request.post("https://github.com/login/device/select_account", {
  form: { authenticity_token: token },
  maxRedirects: 0,
  headers: { Referer: "https://github.com/login/device/select_account" }
});
console.log("select", resp.status());

html = await (await ctx.request.get("https://github.com/login/device?skip_account_picker=true")).text();
token = html.match(/name="authenticity_token" value="([^"]+)"/)?.[1];
const code = device.user_code.replace("-", "");
const confirmForm = { authenticity_token: token, commit: "Continue", "user-code-4": "-" };
for (let i = 0; i < code.length; i++) {
  const idx = i < 4 ? i : i + 1;
  confirmForm[`user-code-${idx}`] = code[i];
}
resp = await ctx.request.post("https://github.com/login/device/confirmation", {
  form: confirmForm,
  headers: { Referer: "https://github.com/login/device?skip_account_picker=true" }
});
html = await resp.text();
const authToken = html.match(/name="authenticity_token" value="([^"]+)"/)?.[1];
const userCode = html.match(/name="user_code" id="user_code" value="([^"]+)"/)?.[1];
console.log("confirmation", resp.status(), "authorize form", !!authToken, userCode);

resp = await ctx.request.post("https://github.com/login/device/authorize", {
  form: {
    authenticity_token: authToken,
    user_code: userCode,
    integration_version_number: "1",
    authorize: "1"
  },
  maxRedirects: 0,
  headers: { Referer: "https://github.com/login/device?skip_account_picker=true" }
});
console.log("authorize", resp.status(), resp.headers()["location"]);

let tokenJson = null;
for (let attempt = 0; attempt < 20; attempt++) {
  const tr = await ctx.request.post("https://github.com/login/oauth/access_token", {
    form: {
      client_id: "Iv1.b507a08c87ecfe98",
      device_code: device.device_code,
      grant_type: "urn:ietf:params:oauth:grant-type:device_code"
    },
    headers: { Accept: "application/json" },
    timeout: 30000
  });
  tokenJson = JSON.parse(await tr.text());
  if (tokenJson.access_token) break;
  if (tokenJson.error !== "authorization_pending" && tokenJson.error !== "slow_down") break;
  await new Promise((r) => setTimeout(r, 3000));
}
console.log(tokenJson?.access_token ? "TOKEN OK" : `TOKEN ERROR ${tokenJson?.error}`);
if (tokenJson?.access_token) {
  writeFileSync(base + "/github-token.json", JSON.stringify(tokenJson, null, 2));
}
await browser.close();
