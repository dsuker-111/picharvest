﻿import { chromium } from 'playwright';
import { readFileSync } from 'node:fs';
const base='C:/Users/lx/Documents/deepseek-harness/default-workspace/gh-tmp';
const data=JSON.parse(readFileSync(base+'/cookies.json','utf8'));
const cookies=data.cookies.filter(c=>c.name&&c.value&&/(^|\.)github\.com$/.test(c.domain)).map(c=>({name:c.name,value:c.value,domain:c.domain,path:c.path||'/',expires:typeof c.expirationDate==='number'?Math.round(c.expirationDate):-1,httpOnly:!!c.httpOnly,secure:!!c.secure,sameSite:['Strict','Lax','None'].includes(c.sameSite)?c.sameSite:'Lax'}));
const b=await chromium.launch({headless:false,channel:'chromium',args:['--disable-blink-features=AutomationControlled']}); const ctx=await b.newContext({ignoreHTTPSErrors:true,viewport:{width:1280,height:1000},userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0'}); await ctx.addCookies(cookies);
const page=await ctx.newPage(); await page.goto('https://github.com/dsuker-111/picharvest/upload/main',{waitUntil:'domcontentloaded',timeout:60000}); await page.waitForTimeout(3000);
const files=[
'C:/Users/lx/Documents/deepseek-harness/default-workspace/picharvest/site/downloads/picharvest-source-v1.0.0.zip',
'C:/Users/lx/Documents/deepseek-harness/default-workspace/picharvest/site/downloads/picharvest-extension-v1.0.0.zip',
'C:/Users/lx/Documents/deepseek-harness/default-workspace/picharvest/site/downloads/SHA256.txt',
'C:/Users/lx/Documents/deepseek-harness/default-workspace/picharvest/site/downloads/SOURCE-SHA256.txt',
'C:/Users/lx/Documents/deepseek-harness/default-workspace/picharvest/MEETING_NOTES.md',
'C:/Users/lx/Documents/deepseek-harness/default-workspace/picharvest/LICENSE'
];
await page.locator('input[type=file]').setInputFiles(files); await page.waitForTimeout(5000);
console.log((await page.locator('body').innerText()).slice(0,1200));
const summary=page.locator('input[placeholder*="summary"], input[name*="summary"], textarea[placeholder*="summary"]'); console.log('summary',await summary.count());
if(await summary.count()) await summary.first().fill('Add project source, extension package and checksums');
const commit=page.getByRole('button',{name:/Commit changes/}).last(); console.log('commit',await commit.count(),await commit.isDisabled()); await commit.click(); await page.waitForTimeout(8000);
console.log('url',page.url()); console.log((await page.locator('body').innerText()).slice(0,600)); await page.screenshot({path:base+'/upload-done.png'}); await b.close();
