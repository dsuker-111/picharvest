﻿import { chromium } from 'playwright';
import { readFileSync, writeFileSync } from 'node:fs';
const base='C:/Users/lx/Documents/deepseek-harness/default-workspace/gh-tmp';
const data=JSON.parse(readFileSync(base+'/cookies.json','utf8'));
const cookies=data.cookies.filter(c=>c.name&&c.value&&/(^|\.)github\.com$/.test(c.domain)).map(c=>({name:c.name,value:c.value,domain:c.domain,path:c.path||'/',expires:typeof c.expirationDate==='number'?Math.round(c.expirationDate):-1,httpOnly:!!c.httpOnly,secure:!!c.secure,sameSite:['Strict','Lax','None'].includes(c.sameSite)?c.sameSite:'Lax'}));
const b=await chromium.launch({headless:true}); const ctx=await b.newContext({ignoreHTTPSErrors:true,userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0'}); await ctx.addCookies(cookies);
const r=await ctx.request.get('https://github.com/settings/apps/new',{timeout:30000}); const h=await r.text(); writeFileSync(base+'/apps-new.html',h); console.log('status',r.status(),'len',h.length,'token',/name="authenticity_token" value="([^"]+)"/.test(h),'form',h.includes('oauth_application'));
console.log(h.slice(0,300));
await b.close();
