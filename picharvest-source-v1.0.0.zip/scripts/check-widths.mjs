﻿import { chromium } from 'playwright';
const browser = await chromium.launch({headless:true});
for (const width of [768, 320]) {
  const page = await browser.newPage({viewport:{width,height:900}});
  await page.goto('http://127.0.0.1:4173/',{waitUntil:'networkidle'});
  await page.evaluate(()=>document.querySelectorAll('.will-reveal').forEach(e=>e.classList.add('is-visible')));
  await page.waitForTimeout(500);
  const m = await page.evaluate(()=>({sw:document.documentElement.scrollWidth,iw:innerWidth}));
  console.log(width, m);
  await page.screenshot({path:`.tmp/hero-${width}.png`});
  await page.close();
}
await browser.close();
