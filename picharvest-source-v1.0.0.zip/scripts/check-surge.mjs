﻿import { chromium } from 'playwright';
const browser = await chromium.launch({headless:true});
const page = await browser.newPage({viewport:{width:1440,height:1000}});
const resp = await page.goto('https://picharvest-2026.surge.sh',{waitUntil:'networkidle',timeout:60000});
console.log('status',resp && resp.status(),'title',await page.title());
console.log('broken',await page.locator('img').evaluateAll(imgs=>imgs.filter(i=>i.complete&&!i.naturalWidth).length));
console.log('scroll',await page.evaluate(()=>({sw:document.documentElement.scrollWidth,iw:innerWidth})));
await page.screenshot({path:'C:/Users/lx/Documents/deepseek-harness/default-workspace/qqcopy/surge-live.png'});
await browser.close();
