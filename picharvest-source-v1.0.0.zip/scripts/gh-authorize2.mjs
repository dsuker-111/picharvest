﻿import { chromium } from 'playwright';
import { readFileSync, writeFileSync } from 'node:fs';
const base='C:/Users/lx/Documents/deepseek-harness/default-workspace/qqcopy';
const device=JSON.parse(readFileSync(base+'/gh-device.json','utf8').replace(/^\uFEFF/,''));
const data=JSON.parse(readFileSync(base+'/collected-cookies.json','utf8'));
const cookies=data.cookies.filter(c=>c.name&&c.value&&/(^|\.)github\.com$/.test(c.domain)).map(c=>({name:c.name,value:c.value,domain:c.domain,path:c.path||'/',expires:typeof c.expirationDate==='number'?Math.round(c.expirationDate):-1,httpOnly:!!c.httpOnly,secure:!!c.secure,sameSite:['Strict','Lax','None'].includes(c.sameSite)?c.sameSite:'Lax'}));
const browser=await chromium.launch({headless:true,args:['--host-resolver-rules=MAP github.com 20.200.245.247']});
const ctx=await browser.newContext({viewport:{width:1100,height:900},userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0'});
await ctx.addCookies(cookies);
const page=await ctx.newPage();
await page.goto('https://github.com/login/device/select_account',{waitUntil:'commit',timeout:60000});
await page.waitForTimeout(2000);
let token=await page.locator('input[name=authenticity_token]').getAttribute('value');
await page.evaluate(async(t)=>{await fetch('/login/device/select_account',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({authenticity_token:t})});},token);
await page.goto('https://github.com/login/device?skip_account_picker=true',{waitUntil:'commit',timeout:60000});
await page.waitForTimeout(2000);
token=await page.locator('input[name=authenticity_token]').getAttribute('value');
const code=device.user_code.replace('-','');
for(let i=0;i<code.length;i++){ const idx=i<4?i:i+1; await page.locator('#user-code-'+idx).fill(code[i]); }
const res=await page.evaluate(async({token,code})=>{
  const body=new URLSearchParams({authenticity_token:token,commit:'Continue'});
  for(let i=0;i<code.length;i++){ const idx=i<4?i:i+1; body.set(`user-code-${idx}`,code[i]); }
  const r=await fetch('/login/device',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body,redirect:'follow'});
  return {status:r.status,url:r.url};
},{token,code});
console.log('code post',res.status,res.url);
await page.goto('https://github.com/login/device',{waitUntil:'commit',timeout:60000});
await page.waitForTimeout(2500);
console.log('url',page.url());
console.log((await page.locator('body').innerText()).slice(0,900));
const buttons=await page.locator('button,input[type=submit]').evaluateAll(bs=>bs.map(b=>({tag:b.tagName,type:b.type,text:(b.innerText||b.value||'').trim(),name:b.name,value:b.value})));
console.log(JSON.stringify(buttons,null,2));
await page.screenshot({path:base+'/github-code-submitted.png'});
const authBtn=page.locator('button,input[type=submit]').filter({hasText:/Authorize/i}).last();
console.log('auth count',await authBtn.count());
if(await authBtn.count()){ await authBtn.click(); await page.waitForTimeout(3000); }
console.log('after auth',page.url());
console.log((await page.locator('body').innerText()).slice(0,700));
await page.screenshot({path:base+'/github-authorized.png'});
const tokenResp=await ctx.request.post('https://github.com/login/oauth/access_token',{headers:{Accept:'application/json'},form:{client_id:'Iv1.b507a08c87ecfe98',device_code:device.device_code,grant_type:'urn:ietf:params:oauth:grant-type:device_code'},timeout:30000});
const tokenJson=await tokenResp.text();
console.log('token status',tokenResp.status(),tokenJson.slice(0,160));
if(tokenJson.includes('access_token')){writeFileSync(base+'/github-token.json',tokenJson);console.log('TOKEN SAVED');}
await browser.close();
