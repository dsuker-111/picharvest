﻿import { chromium } from 'playwright';
const browser = await chromium.launch({headless:true});
const ctx = await browser.newContext();
try {
  const r = await ctx.request.post('https://github.com/login/device/code', {
    headers:{'Accept':'application/json','Content-Type':'application/json'},
    data:{client_id:'Iv1.b507a08c87ecfe98', scope:'repo read:user'},
    timeout:60000
  });
  console.log(r.status());
  console.log((await r.text()).slice(0,1000));
} catch(e) { console.log('ERR',e.message); }
await browser.close();
