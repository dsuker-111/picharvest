﻿import { chromium } from 'playwright';
const b=await chromium.launch({headless:true}); const p=await b.newPage({viewport:{width:768,height:900}});
await p.goto('http://127.0.0.1:4173/',{waitUntil:'networkidle'}); await p.waitForTimeout(300);
const box=await p.locator('.nav').evaluate(e=>({w:e.scrollWidth,cw:e.clientWidth,links:[...e.querySelectorAll('.nav-links a')].map(a=>({t:a.textContent,r:a.getBoundingClientRect().toJSON()}))}));
console.log(JSON.stringify(box,null,2));
await p.screenshot({path:'C:/Users/lx/Documents/deepseek-harness/default-workspace/picharvest/nav-768.png'});
await b.close();
