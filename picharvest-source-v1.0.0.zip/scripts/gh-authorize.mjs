﻿import { chromium } from 'playwright';
import { readFileSync, writeFileSync } from 'node:fs';
const base='C:/Users/lx/Documents/deepseek-harness/default-workspace/qqcopy';
const device = JSON.parse(readFileSync(base+'/gh-device.json','utf8').replace(/^\uFEFF/,''));
const data = JSON.parse(readFileSync(base+'/collected-cookies.json','utf8'));
const cookies = data.cookies.filter(c=>c.name&&c.value&&/(^|\.)github\.com$/.test(c.domain)).map(c=>({name:c.name,value:c.value,domain:c.domain,path:c.path||'/',expires:typeof c.expirationDate==='number'?Math.round(c.expirationDate):-1,httpOnly:!!c.httpOnly,secure:!!c.secure,sameSite:['Strict','Lax','None'].includes(c.sameSite)?c.sameSite:'Lax'}));
const browser = await chromium.launch({headless:true,args:['--host-resolver-rules=MAP github.com 20.27.177.113']});
const ctx = await browser.newContext({viewport:{width:1100,height:900},userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0'});
await ctx.addCookies(cookies);
const page = await ctx.newPage();
await page.goto('https://github.com/login/device',{waitUntil:'commit',timeout:60000});
await page.waitForTimeout(2500);
console.log('step',page.url());
if(page.url().includes('select_account')){
  await page.evaluate(()=>document.querySelector('form[action="/login/device/select_account"]')?.submit());
  await page.waitForTimeout(3000);
}
console.log('after select',page.url());
await page.waitForSelector('#user-code-0',{timeout:15000});
const code = device.user_code.replace('-','');
for (let i=0;i<code.length;i++) await page.locator(`#user-code-${i}`).fill(code[i]);
await page.locator('input[type=submit]').click();
await page.waitForTimeout(3000);
console.log('after code',page.url());
console.log((await page.locator('body').innerText()).slice(0,1200));
const buttons = await page.locator('button,input[type=submit]').evaluateAll(bs=>bs.map(b=>({tag:b.tagName,type:b.type,text:(b.innerText||b.value||'').trim(),name:b.name,value:b.value})));
console.log(JSON.stringify(buttons,null,2));
await page.screenshot({path:base+'/github-authorize.png'});
let authBtn = page.locator('button,input[type=submit]').filter({hasText:/Authorize/i}).last();
if(!(await authBtn.count())) authBtn = page.locator('button[type=submit]').last();
console.log('auth count',await authBtn.count());
if(await authBtn.count()){ await authBtn.click(); await page.waitForTimeout(3500); }
console.log('after auth',page.url());
console.log((await page.locator('body').innerText()).slice(0,800));
await page.screenshot({path:base+'/github-authorized.png'});
const tokenResp = await ctx.request.post('https://github.com/login/oauth/access_token',{headers:{Accept:'application/json'},form:{client_id:'Iv1.b507a08c87ecfe98',device_code:device.device_code,grant_type:'urn:ietf:params:oauth:grant-type:device_code'},timeout:30000});
console.log('token status',tokenResp.status());
const tokenJson = await tokenResp.text();
console.log(tokenJson.slice(0,200));
if(tokenJson.includes('access_token')) { writeFileSync(base+'/github-token.json',tokenJson); console.log('TOKEN SAVED'); }
await browser.close();
