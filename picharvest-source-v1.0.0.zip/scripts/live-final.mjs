﻿import { chromium } from 'playwright';
const b=await chromium.launch({headless:true}); const p=await b.newPage({viewport:{width:1440,height:1000}});
const r=await p.goto('https://picharvest-2026.surge.sh/#usage',{waitUntil:'networkidle',timeout:60000});
console.log('status',r.status(),'title',await p.title());
console.log('broken',await p.locator('img').evaluateAll(imgs=>imgs.filter(i=>i.complete&&!i.naturalWidth).map(i=>i.getAttribute('src'))));
console.log('scroll',await p.evaluate(()=>({sw:document.documentElement.scrollWidth,iw:innerWidth})));
await p.screenshot({path:'C:/Users/lx/Documents/deepseek-harness/default-workspace/picharvest/site/assets/live-home.png'});
await b.close();
