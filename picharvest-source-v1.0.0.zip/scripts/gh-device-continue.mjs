﻿import { chromium } from 'playwright';
import { readFileSync } from 'node:fs';
const data = JSON.parse(readFileSync('C:/Users/lx/Documents/deepseek-harness/default-workspace/qqcopy/collected-cookies.json','utf8'));
const cookies = data.cookies.filter(c=>c.name&&c.value&&/(^|\.)github\.com$/.test(c.domain)).map(c=>({name:c.name,value:c.value,domain:c.domain,path:c.path||'/',expires:typeof c.expirationDate==='number'?Math.round(c.expirationDate):-1,httpOnly:!!c.httpOnly,secure:!!c.secure,sameSite:['Strict','Lax','None'].includes(c.sameSite)?c.sameSite:'Lax'}));
const browser = await chromium.launch({headless:true,args:['--host-resolver-rules=MAP github.com 20.27.177.113']});
const ctx = await browser.newContext({viewport:{width:1100,height:900},userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0'});
await ctx.addCookies(cookies);
const page = await ctx.newPage();
await page.goto('https://github.com/login/device',{waitUntil:'commit',timeout:60000});
await page.waitForTimeout(2500);
console.log('1',page.url(),(await page.locator('body').innerText()).slice(0,500));
const submit = page.locator('input[type=submit]').first();
console.log('submit count',await submit.count(), await submit.getAttribute('value'));
if(await submit.count()){ await submit.click(); await page.waitForTimeout(3500); }
console.log('2',page.url(),(await page.locator('body').innerText()).slice(0,1200));
console.log('inputs',await page.locator('input').evaluateAll(ins=>ins.map(i=>({name:i.name,id:i.id,type:i.type,ph:i.placeholder,value:i.value}))));
await page.screenshot({path:'C:/Users/lx/Documents/deepseek-harness/default-workspace/qqcopy/github-device-2.png'});
await browser.close();
