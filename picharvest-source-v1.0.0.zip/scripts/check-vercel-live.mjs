﻿import { chromium } from 'playwright';
const browser = await chromium.launch({headless:true});
const page = await browser.newPage({viewport:{width:1440,height:1000}});
const resp = await page.goto('https://rapid-flint-7mtpu6i.tmp.now',{waitUntil:'networkidle',timeout:60000});
console.log('status',resp && resp.status(),'url',page.url(),'title',await page.title());
console.log((await page.locator('body').innerText()).slice(0,1200));
console.log('imgs', await page.locator('img').count());
await page.screenshot({path:'C:/Users/lx/Documents/deepseek-harness/default-workspace/qqcopy/vercel-live.png'});
await browser.close();
