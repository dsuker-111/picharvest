﻿import { WebSocket } from 'ws';
import http from 'node:http';
const get = (url) => new Promise((res,rej)=>http.get(url,r=>{let d='';r.on('data',c=>d+=c);r.on('end',()=>res(d))}).on('error',rej));
const list = JSON.parse(await get('http://127.0.0.1:9222/json/list'));
console.log(list.map(x=>({type:x.type,url:x.url,ws:x.webSocketDebuggerUrl})));
const target = list.find(x=>x.type==='page');
if(!target){console.log('no page');process.exit(0);}
const ws = new WebSocket(target.webSocketDebuggerUrl, { origin: 'http://127.0.0.1:9222' });
ws.on('open',()=>{ console.log('OPEN'); ws.send(JSON.stringify({id:1,method:'Runtime.evaluate',params:{expression:'document.title'}})); });
ws.on('message',(m)=>{console.log('MSG',m.toString().slice(0,500)); ws.close();});
ws.on('error',(e)=>{console.log('ERR',e.message); process.exit(1);});
setTimeout(()=>{console.log('TIMEOUT');process.exit(2)},8000);
