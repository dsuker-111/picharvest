﻿import { chromium } from 'playwright';
const browser=await chromium.launch({headless:true});
const page=await browser.newPage({viewport:{width:1440,height:1000}});
await page.goto('http://127.0.0.1:4173/',{waitUntil:'networkidle'});
await page.evaluate(()=>document.querySelectorAll('.will-reveal').forEach(e=>e.classList.add('is-visible')));
await page.waitForTimeout(600);
await page.locator('#usage').screenshot({path:'C:/Users/lx/Documents/deepseek-harness/default-workspace/picharvest/usage-section.png'});
const out=[];
for (const w of [1440,1024,900,768,430,390,320]) {
 await page.setViewportSize({width:w,height:900});
 await page.goto('http://127.0.0.1:4173/',{waitUntil:'networkidle'});
 const m=await page.evaluate(()=>({sw:document.documentElement.scrollWidth,iw:innerWidth}));
 if(m.sw>m.iw+1) out.push({w,...m});
}
console.log('overflow',JSON.stringify(out));
await browser.close();
