﻿import { chromium } from 'playwright';
const browser = await chromium.launch({headless:true});
const ctx = await browser.newContext({viewport:{width:1440,height:1000},userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0'});
const page = await ctx.newPage();
const resp = await page.goto('https://rapid-flint-7mtpu6i.tmp.now',{waitUntil:'domcontentloaded',timeout:60000});
console.log('status',resp && resp.status(),'title',await page.title());
console.log((await page.locator('body').innerText()).slice(0,800));
await browser.close();
